# Changelog

### 0.9

- Removed language to adding better language support.
- Added MutationObserver to handle lazyload and others.
- Script base made modular
- Added OnInput, OnChange event call to simulate user.
- Fuzzy Select by LevenshteinDistance algorithm